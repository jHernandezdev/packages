<?php
use humhub\modules\content\widgets\ContainerProfileHeader;

/* @var $this \humhub\modules\ui\view\components\View */
/* @var $space  \humhub\modules\space\models\Space */


?>

<?= ContainerProfileHeader::widget(['container' => $space]) ?>
