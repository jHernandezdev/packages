<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2016 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace humhub\modules\space\modules\manage\widgets;

/**
 * Menu compatibility
 *
 * @see \humhub\modules\space\widgets\HeaderControlsMenu
 * @deprecated since version 1.1
 * @author Luke
 */
class Menu extends \humhub\modules\space\widgets\HeaderControlsMenu
{
    
}