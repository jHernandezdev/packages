<?php
return array (
  'Friendship' => 'Arkadaşlık',
  'Receive Notifications for Friendship Request and Approval events.' => '',
  '{displayName} accepted your friend request.' => '{displayName} arkadaşlık isteğini kabul etti.',
  '{displayName} declined your friend request.' => '{displayName} arkadaşlık isteğinizi reddetti.',
  '{displayName} sent you a friend request.' => '{displayName} arkadaşlık isteği gönderdi.',
);
