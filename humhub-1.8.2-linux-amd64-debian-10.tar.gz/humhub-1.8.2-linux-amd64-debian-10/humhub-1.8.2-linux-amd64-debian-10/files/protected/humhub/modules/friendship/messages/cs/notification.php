<?php
return array (
  'Friendship' => 'Přátelství',
  'Receive Notifications for Friendship Request and Approval events.' => 'Obdržíte oznámení o událostech žádosti o přátelství a schválení.',
  '{displayName} accepted your friend request.' => '{displayName} přijal/a Vaši žádost o přátelství.',
  '{displayName} declined your friend request.' => '{displayName} odmítl/a Vaši žádost o přátelství.',
  '{displayName} sent you a friend request.' => '{displayName} Vám posílá žádost o přátelství.',
);
