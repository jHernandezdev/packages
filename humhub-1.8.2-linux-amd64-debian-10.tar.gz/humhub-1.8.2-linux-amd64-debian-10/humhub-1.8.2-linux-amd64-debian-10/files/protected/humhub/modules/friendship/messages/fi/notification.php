<?php
return array (
  'Friendship' => 'Ystävyys',
  'Receive Notifications for Friendship Request and Approval events.' => 'Saa ilmoituket ystävyyden pyyntö- ja hyväksyntätapahtumista.',
  '{displayName} accepted your friend request.' => '{displayName} hyväksyi ystäväsi pyyntösi.',
  '{displayName} declined your friend request.' => '{displayName} hylkäsi ystäväsi pyyntösi.',
  '{displayName} sent you a friend request.' => '{displayName} lähetti sinulle ystäväpyynnön.',
);
