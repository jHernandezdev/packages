<?php
return array (
  '<strong>My</strong> friends' => 'Prietenii <strong>Mei</strong>',
  '<strong>Pending</strong> friend requests' => 'Cereri de prietenie <strong>În așteptare</strong>',
  '<strong>Sent</strong> friend requests' => 'Cereri de prietenie <strong>Trimise</strong>',
  'Accept Friend Request' => 'Acceptă Cerea De Prietenie',
  'Add Friend' => 'Adaugă Prieten',
  'Cancel friend request' => 'Respinge cererea de prietenie',
  'Deny friend request' => 'Respinge cererea de prietenie',
  'Friends' => 'Prieteni',
  'Friendship' => 'Prietenie',
  'Requests' => 'Cereri',
  'Sent requests' => 'Cereri trimise',
  'Show all friends' => 'Arată toți prietenii',
  'Unfriend' => 'Nu mai fi-ți prieteni',
);
