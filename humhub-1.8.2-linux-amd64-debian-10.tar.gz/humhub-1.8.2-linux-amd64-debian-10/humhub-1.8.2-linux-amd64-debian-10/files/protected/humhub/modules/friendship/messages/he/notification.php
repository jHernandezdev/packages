<?php
return array (
  'Friendship' => 'חברות',
  'Receive Notifications for Friendship Request and Approval events.' => 'קבל התראות לבקשות חברות ואישורים נדרשים',
  '{displayName} accepted your friend request.' => '{displayName}  קיבל את בקשת החברות',
  '{displayName} declined your friend request.' => '{displayName} דחה את בקשת החברות',
  '{displayName} sent you a friend request.' => '{displayName}  שלח לך בקשת חברות',
);
