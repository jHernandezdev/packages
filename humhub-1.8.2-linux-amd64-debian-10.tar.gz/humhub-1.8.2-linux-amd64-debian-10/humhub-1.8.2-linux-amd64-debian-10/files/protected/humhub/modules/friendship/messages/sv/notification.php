<?php
return array (
  'Friendship' => 'Vänskap',
  'Receive Notifications for Friendship Request and Approval events.' => 'Få notiser för vänförfrågningar & dess godkännanden.',
  '{displayName} accepted your friend request.' => '{displayName} accepterade vänförfrågan',
  '{displayName} declined your friend request.' => '{displayName} nekade din vänförfrågan.',
  '{displayName} sent you a friend request.' => '{displayName} skickade dig en vänförfrågan.',
);
