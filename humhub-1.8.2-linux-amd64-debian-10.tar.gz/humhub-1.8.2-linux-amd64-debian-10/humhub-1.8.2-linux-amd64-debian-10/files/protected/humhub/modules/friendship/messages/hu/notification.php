<?php
return array (
  'Friendship' => 'Ismertség',
  'Receive Notifications for Friendship Request and Approval events.' => 'Értesítések fogadása ismerősnek jelölésekről és azok elfogadásáról.',
  '{displayName} accepted your friend request.' => '{displayName} visszajelezte, hogy ismer.',
  '{displayName} declined your friend request.' => '{displayName} elutasította a jelölést.',
  '{displayName} sent you a friend request.' => '{displayName} ismerősnek jelölt.',
);
