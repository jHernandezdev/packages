<?php
return array (
  'Friendship' => 'Amicizia',
  'Receive Notifications for Friendship Request and Approval events.' => 'Riceve Notifiche per richieste amicizia e eventi approvazione.',
  '{displayName} accepted your friend request.' => '{displayName} ha accettato la tua richiesta di amicizia',
  '{displayName} declined your friend request.' => '{displayName} ha declinato la tua richiesta di amicizia',
  '{displayName} sent you a friend request.' => '{displayName} ti ha inviato una richiesta di amicizia',
);
