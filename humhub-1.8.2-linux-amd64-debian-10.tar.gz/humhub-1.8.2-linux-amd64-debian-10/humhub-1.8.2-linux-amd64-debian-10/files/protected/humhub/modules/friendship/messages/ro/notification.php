<?php
return array (
  'Friendship' => 'Prietenie',
  'Receive Notifications for Friendship Request and Approval events.' => 'Primește Notificări pentru Cereri de Prietenie și evenimente de Aprobare.',
  '{displayName} accepted your friend request.' => '{displayName} ți-a acceptat cererea de prietenie.',
  '{displayName} declined your friend request.' => '{displayName} ți-a respins cererea de prietenie.',
  '{displayName} sent you a friend request.' => '{displayName} ți-a trimis o cerere de prietenie.',
);
