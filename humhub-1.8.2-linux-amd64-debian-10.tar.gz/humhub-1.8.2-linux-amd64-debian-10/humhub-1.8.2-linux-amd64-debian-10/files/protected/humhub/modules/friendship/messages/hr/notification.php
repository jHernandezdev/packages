<?php
return array (
  'Friendship' => 'Prijateljstvo',
  'Receive Notifications for Friendship Request and Approval events.' => 'Primajte obavijesti o događajima o zahtjevu i odobrenju prijateljstva.',
  '{displayName} accepted your friend request.' => '{displayName} prihvatio je tvoj zahtjev za prijateljstvom.',
  '{displayName} declined your friend request.' => '{displayName} odbio je tvoj zahtjev za prijateljstvom.',
  '{displayName} sent you a friend request.' => '{displayName} poslao vam je zahtjev za prijateljstvom.',
);
