<?php
return array (
  'Friendship' => 'Приятелство',
  'Receive Notifications for Friendship Request and Approval events.' => 'Получавайте известия за заявки за приятелство и събития за одобрение.',
  '{displayName} accepted your friend request.' => '{displayName} прие заявката ви за приятелство.',
  '{displayName} declined your friend request.' => '{displayName} отхвърли заявката ви за приятелство.',
  '{displayName} sent you a friend request.' => '{displayName} ви изпрати заявка за приятелство.',
);
