<?php
return array (
  'Friendship' => 'Amistad',
  'Receive Notifications for Friendship Request and Approval events.' => 'Recibir notificaciones de petición de amistad y eventos.',
  '{displayName} accepted your friend request.' => '{displayName} aceptó tu solicitud de amistad.',
  '{displayName} declined your friend request.' => '{displayName} rechazó tu solicitud de amistad.',
  '{displayName} sent you a friend request.' => '{displayName} te envió una solicitud de amistad.',
);
