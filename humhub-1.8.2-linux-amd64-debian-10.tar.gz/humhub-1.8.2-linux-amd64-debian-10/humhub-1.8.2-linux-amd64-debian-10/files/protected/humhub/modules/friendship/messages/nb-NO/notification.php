<?php
return array (
  'Friendship' => 'Vennskap',
  'Receive Notifications for Friendship Request and Approval events.' => 'Motta notifikasjon for venneforespørsler og hendelser.',
  '{displayName} accepted your friend request.' => '{displayName} godkjente din venneforespørsel.',
  '{displayName} declined your friend request.' => '{displayName} avviste din venneforespørsel.',
  '{displayName} sent you a friend request.' => '{displayName} sendte deg en venneforespørsel.',
);
