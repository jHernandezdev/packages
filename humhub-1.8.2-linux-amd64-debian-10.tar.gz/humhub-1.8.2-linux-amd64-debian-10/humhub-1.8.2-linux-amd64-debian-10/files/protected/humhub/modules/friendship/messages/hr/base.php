<?php
return array (
  '<strong>My</strong> friends' => '<strong>Moji</strong> prijatelji',
  '<strong>Pending</strong> friend requests' => '<strong>Na čekanju</strong> zahtjev za prijateljstvom',
  '<strong>Sent</strong> friend requests' => '<strong>Poslan</strong> zahtjev za prijateljstvom',
  'Accept Friend Request' => 'Prihvati zahtjev za prijateljstvom',
  'Add Friend' => 'Dodaj prijatelja',
  'Cancel friend request' => 'Otkaži zahtjev za prijateljstvom',
  'Deny friend request' => 'Odbaci zahtjev za prijateljstvom',
  'Friends' => 'Prijatelji',
  'Friendship' => 'Prijateljstvo',
  'Requests' => 'Zahtjevi',
  'Sent requests' => 'Poslani zahtjevi',
  'Show all friends' => 'Prikaži sve prijatelje',
  'Unfriend' => 'Unfriend',
);
