<?php
return array (
  'Friendship' => '好友',
  'Receive Notifications for Friendship Request and Approval events.' => '接收友情请求和批准事件的通知。',
  '{displayName} accepted your friend request.' => '{displayName} 通过了你的好友请求。',
  '{displayName} declined your friend request.' => '{displayName} 拒绝了你的好友请求。',
  '{displayName} sent you a friend request.' => '{displayName} 给你发送了一个好友请求。',
);
