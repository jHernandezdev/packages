<?php
return array (
  'Friendship' => 'Freundschaft',
  'Receive Notifications for Friendship Request and Approval events.' => 'Benachrichtigungen für Freundschaftsanfragen und Genehmigungen erhalten.',
  '{displayName} accepted your friend request.' => '{displayName} hat deine Freundschaftsanfrage akzeptiert.',
  '{displayName} declined your friend request.' => '{displayName} hat deine Freundschaftsanfrage abgelehnt.',
  '{displayName} sent you a friend request.' => '{displayName} hat Dir eine Freundschaftsanfrage gesendet.',
);
