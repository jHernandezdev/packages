<?php

/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace humhub\widgets;

use humhub\modules\ui\form\widgets\JsInputWidget;

/**
 * @see JsInputWidget
 * @deprecated since 1.3
 * @author Luke
 * @since 2.0
 */
class InputWidget extends JsInputWidget
{
}
