<?php
/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2017 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 *
 */

/**
 * Created by PhpStorm.
 * User: buddha
 * Date: 18.07.2017
 * Time: 10:59
 */

namespace humhub\widgets;


class SettingsTabs extends Tabs
{
    public $navType = 'nav-tabs tab-menu tab-menu-settings';
}
