<?php

namespace humhub\widgets;

use humhub\modules\ui\form\widgets\MultiSelect;

/**
 * @see MultiSelect
 * @deprecated since 1.3
 * @since 1.2
 * @author buddha
 */
class MultiSelectField extends MultiSelect
{
}
