<?php

namespace humhub\widgets;

/**
 * @deprecated since 1.3
 * @since 1.2
 * @author buddha
 */
abstract class BasePickerField extends \humhub\modules\ui\form\widgets\BasePicker
{

}
