<script <?= \humhub\libs\Html::nonce() ?>>
    $('#globalModal').modal('hide');
</script>