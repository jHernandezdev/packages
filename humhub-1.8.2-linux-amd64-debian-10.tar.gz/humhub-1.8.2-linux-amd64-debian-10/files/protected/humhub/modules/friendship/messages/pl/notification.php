<?php
return array (
  'Friendship' => 'Znajomość',
  'Receive Notifications for Friendship Request and Approval events.' => 'Otrzymuj powiadomienia dla Zaproszeń do znajomych i Akceptacji wydarzeń.',
  '{displayName} accepted your friend request.' => '{displayName} zaakceptował(a) Twoją prośbę o przyłączenie do grona znajomych.',
  '{displayName} declined your friend request.' => '{displayName} odrzucił(a) Twoją prośbę o przyłączenie do grona znajomych.',
  '{displayName} sent you a friend request.' => '{displayName} wysłał(a) Ci prośbę o przyłączenie do grona znajomych.',
);
