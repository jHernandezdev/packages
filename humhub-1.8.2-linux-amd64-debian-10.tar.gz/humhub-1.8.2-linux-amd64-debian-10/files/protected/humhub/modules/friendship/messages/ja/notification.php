<?php
return array (
  'Friendship' => 'フレンドシップ',
  'Receive Notifications for Friendship Request and Approval events.' => '',
  '{displayName} accepted your friend request.' => '',
  '{displayName} declined your friend request.' => '',
  '{displayName} sent you a friend request.' => '',
);
