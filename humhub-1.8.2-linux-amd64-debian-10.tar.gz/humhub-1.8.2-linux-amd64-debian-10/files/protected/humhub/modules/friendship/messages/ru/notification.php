<?php
/**
 * Translation: Paul (https://paul.bid) paulbid@protonmail.com
 * 
 */
return array (
  'Friendship' => 'Дружба',
  'Receive Notifications for Friendship Request and Approval events.' => 'Получать уведомления о запросах дружбы и одобрения дружбы.',
  '{displayName} accepted your friend request.' => 'Пользователь {displayName} принял(а) Ваш запрос на добавление в друзья.',
  '{displayName} declined your friend request.' => 'Пользователь {displayName} отклонил(а) Ваш запрос на добавление в друзья.',
  '{displayName} sent you a friend request.' => 'Пользователь {displayName} отправил(а) Вам запрос на добавление в друзья.',
);
