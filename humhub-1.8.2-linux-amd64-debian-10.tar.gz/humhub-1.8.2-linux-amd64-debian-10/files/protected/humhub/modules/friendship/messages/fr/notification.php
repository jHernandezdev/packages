<?php
return array (
  'Friendship' => 'Amitié',
  'Receive Notifications for Friendship Request and Approval events.' => 'Recevoir une notification lorsqu\'on m\'envoie ou accepte une demande d\'amitié.',
  '{displayName} accepted your friend request.' => '{displayName} est désormais votre ami.',
  '{displayName} declined your friend request.' => '{displayName} a refusé d\'être votre ami.',
  '{displayName} sent you a friend request.' => '{displayName} a demandé à être votre ami.',
);
