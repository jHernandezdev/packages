<?php
return array (
  'Friendship' => 'Vriendschap',
  'Receive Notifications for Friendship Request and Approval events.' => 'Ontvang meldingen voor vriendschapsverzoeken en andere uitnodigingen.',
  '{displayName} accepted your friend request.' => '{displayName} heeft je vriendschapsverzoek goedgekeurd.',
  '{displayName} declined your friend request.' => '{displayName} heeft je vriendschapsverzoek geweigerd.',
  '{displayName} sent you a friend request.' => '{displayName} heeft je een vriendschapsverzoek gestuurd.',
);
