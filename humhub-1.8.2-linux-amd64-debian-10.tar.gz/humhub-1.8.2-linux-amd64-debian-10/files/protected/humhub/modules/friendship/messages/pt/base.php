<?php
return array (
  '<strong>My</strong> friends' => '<strong>My</strong> amigas',
  '<strong>Pending</strong> friend requests' => '<strong>Pending</strong> pedidos de amigas',
  '<strong>Sent</strong> friend requests' => '<strong>Sent</strong> pedidos de amigas',
  'Accept Friend Request' => 'Aceitar pedido de amizade',
  'Add Friend' => 'Adicionar amiga',
  'Cancel friend request' => 'Queres mesmo cancelar um pedido de amizade?',
  'Deny friend request' => 'Não se nega um pedido de amizade',
  'Friends' => 'Amigas',
  'Friendship' => 'Amizade',
  'Requests' => 'Pedidos',
  'Sent requests' => 'Enviar pedidos',
  'Show all friends' => 'Mostrar todas amigas',
  'Unfriend' => 'Inimaginável',
);
