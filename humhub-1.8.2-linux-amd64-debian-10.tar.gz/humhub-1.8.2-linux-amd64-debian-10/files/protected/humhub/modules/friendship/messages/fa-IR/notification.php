<?php
return array (
  'Friendship' => 'دوستی',
  'Receive Notifications for Friendship Request and Approval events.' => 'برای درخواست‌های دوستی و رویدادهای تأیید آگهی بپذیر',
  '{displayName} accepted your friend request.' => '{displayName} درخواست دوستی شما را پذیرفت.',
  '{displayName} declined your friend request.' => '{displayName} درخواست دوستی شما را نپذیرفت.',
  '{displayName} sent you a friend request.' => '{displayName} برای شما درخواست دوستی فرستاد.',
);
