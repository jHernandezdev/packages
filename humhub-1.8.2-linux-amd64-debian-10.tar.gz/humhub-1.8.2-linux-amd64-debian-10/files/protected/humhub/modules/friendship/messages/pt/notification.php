<?php
return array (
  'Friendship' => 'Amizade',
  'Receive Notifications for Friendship Request and Approval events.' => 'Receber notificações de pedidos de amizada e aprovação de eventos.',
  '{displayName} accepted your friend request.' => '{displayName} aceitou o teu pedido de amizade.',
  '{displayName} declined your friend request.' => '{displayName} não aceitou o teu pedido de amizade.',
  '{displayName} sent you a friend request.' => '{displayName} enviou-te um pedido de amizade.',
);
