<?php
return array (
  '<strong>My</strong> friends' => '<strong>Моите</strong> приятели',
  '<strong>Pending</strong> friend requests' => '<strong>Изчакващи</strong> заявки за приятелство',
  '<strong>Sent</strong> friend requests' => '<strong>Изпратени</strong> заявки за приятелство',
  'Accept Friend Request' => 'Приемете заявка за приятелство',
  'Add Friend' => 'Добави приятел',
  'Cancel friend request' => 'Отмени заявката за приятелство',
  'Deny friend request' => 'Откажи молба за приятелство',
  'Friends' => 'Приятели',
  'Friendship' => 'Приятелство',
  'Requests' => 'Заявки',
  'Sent requests' => 'Изпратени заявки',
  'Show all friends' => 'Покажи всички приятели',
  'Unfriend' => 'Прекрати приятелство',
);
