<?php
return array (
  'Friendship' => 'Quan hệ bạn bè',
  'Receive Notifications for Friendship Request and Approval events.' => 'Nhận thông báo khi có yêu cầu kết bạn và sự kiện được xét duyệt.',
  '{displayName} accepted your friend request.' => '{displayName} đã chấp thuận yêu cầu kết bạn của bạn.',
  '{displayName} declined your friend request.' => '{displayName} đã từ chối yêu cầu kết bạn của bạn.',
  '{displayName} sent you a friend request.' => '{displayName} đã gửi bạn yêu cầu kết bạn.',
);
