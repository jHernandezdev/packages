<?php
return array (
  'Friendship' => 'Amizade',
  'Receive Notifications for Friendship Request and Approval events.' => 'Receber notificações para requisições de amizade e aprovação de eventos.',
  '{displayName} accepted your friend request.' => '{displayName} aceitou sua solicitação de amizade.',
  '{displayName} declined your friend request.' => '{displayName} rejeitou sua solicitação de amizade.',
  '{displayName} sent you a friend request.' => '{displayName} enviou para você uma solicitação de amizade.',
);
