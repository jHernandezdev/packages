<?php

return [
    'fixtures' => [
        'default'
    ]
];
