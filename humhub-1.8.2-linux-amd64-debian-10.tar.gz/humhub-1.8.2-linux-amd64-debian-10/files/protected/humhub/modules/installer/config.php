<?php

return [
    'id' => 'installer',
    'class' => humhub\modules\installer\Module::class,
    'isCoreModule' => true,
];
?>