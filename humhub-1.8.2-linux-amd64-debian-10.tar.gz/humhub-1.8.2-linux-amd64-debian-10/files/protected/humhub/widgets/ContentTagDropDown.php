<?php
/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2018 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 *
 */

namespace humhub\widgets;


/**
 * Class ContentTagDropDown
 *
 * @see \humhub\modules\content\widgets\ContentTagDropDown
 * @deprecated since 1.3
 * @package humhub\widgets
 */
class ContentTagDropDown extends \humhub\modules\content\widgets\ContentTagDropDown
{
}
