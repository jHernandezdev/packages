<?php
/* @var $content string */
?>

<div class="markdown-render">
    <?= $content; ?>
</div>