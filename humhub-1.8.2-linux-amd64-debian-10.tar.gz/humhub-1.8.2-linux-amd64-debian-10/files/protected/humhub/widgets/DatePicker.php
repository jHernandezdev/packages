<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2017 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace humhub\widgets;


/**
 * DatePicker
 *
 * @see \humhub\modules\ui\form\widgets\DatePicker
 * @deprecated since 1.3
 * @package humhub\widgets
 */
class DatePicker extends \humhub\modules\ui\form\widgets\DatePicker
{

}
