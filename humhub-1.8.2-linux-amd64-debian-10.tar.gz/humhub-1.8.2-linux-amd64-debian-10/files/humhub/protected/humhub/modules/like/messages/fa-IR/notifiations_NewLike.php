<?php
return array (
  'New Like' => 'لايك جديد',
);
