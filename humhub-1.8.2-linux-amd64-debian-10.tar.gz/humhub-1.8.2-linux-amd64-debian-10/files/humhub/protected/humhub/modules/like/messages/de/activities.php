<?php
return array (
  'Likes' => 'Gefällt mir',
  'Whenever someone likes something (e.g. a post or comment).' => 'Wann immer jemandem etwas gefällt (z. B. Beitrag oder Kommentar).',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} gefällt {contentTitle}',
);
