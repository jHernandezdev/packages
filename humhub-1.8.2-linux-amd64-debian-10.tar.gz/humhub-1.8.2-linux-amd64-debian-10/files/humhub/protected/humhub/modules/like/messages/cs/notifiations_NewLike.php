<?php
return array (
  'New Like' => 'Nové To se mi líbí',
);
