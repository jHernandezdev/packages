<?php
return array (
  'Likes' => 'To se mi líbí',
  'Receive Notifications when someone likes your content.' => 'Obdržet oznámení, pokud se někomu líbí Váš příspěvek.',
  'View Online' => 'Zobrazit online',
  '{displayNames} likes your {contentTitle}.' => 'Uživatelům {displayNames} se líbí Váš příspěvek {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => 'Uživatelům {displayNames} se líbí příspěvek {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => 'Uživateli {displayName} se líbí Váš příspěvek {contentTitle}.',
  '{displayName} likes {contentTitle}.' => 'Uživateli {displayName} se líbí příspěvek {contentTitle}.',
);
