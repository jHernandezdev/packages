<?php
return array (
  'Likes' => 'پسندها',
  'Receive Notifications when someone likes your content.' => 'دریافت آگهی هنگامی که کسی محتوای شما را می‌پسندد.',
  'View Online' => 'نمایش آنلاین',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} {contentTitle} شما را می‌پسندد.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} {contentTitle} را می‌پسندد.',
  '{displayName} likes your {contentTitle}.' => '{displayName} {contentTitle} شما را می‌پسندد.',
  '{displayName} likes {contentTitle}.' => '{displayName} {contentTitle} را می‌پسندد.',
);
