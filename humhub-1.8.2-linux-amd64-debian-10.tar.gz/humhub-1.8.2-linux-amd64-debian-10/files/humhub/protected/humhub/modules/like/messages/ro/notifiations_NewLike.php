<?php
return array (
  'New Like' => 'Apreciere Nouă',
);
