<?php
return array (
  'Likes' => 'Piace',
  'Whenever someone likes something (e.g. a post or comment).' => 'Ogni volta a qualcuno piace qualcosa (es. un post o un commento).',
  '{userDisplayName} likes {contentTitle}' => 'A {userDisplayName} piace {contentTitle}',
);
