<?php
return array (
  'Likes' => 'אהבות',
  'Whenever someone likes something (e.g. a post or comment).' => '',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} אהב את {contentTitle}',
);
