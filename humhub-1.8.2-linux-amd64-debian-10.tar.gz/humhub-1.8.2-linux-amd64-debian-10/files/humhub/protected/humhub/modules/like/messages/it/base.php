<?php
return array (
  ' likes this.' => ' piace questo.',
  '<strong>Users</strong> who like this' => '<strong>Utenti</strong> ai quali piace',
  'Like' => 'Mi piace',
  'Unlike' => 'Non mi piace più',
  'You' => 'Tu',
  'You like this.' => 'Ti piace.',
  'and {count} more like this.' => 'e ad altri {count} piace questo.',
);
