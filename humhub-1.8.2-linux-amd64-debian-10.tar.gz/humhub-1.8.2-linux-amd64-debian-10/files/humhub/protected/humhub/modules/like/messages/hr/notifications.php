<?php
return array (
  'Likes' => 'Sviđa',
  'Receive Notifications when someone likes your content.' => 'Primi Obavijesti kada se nekome sviđa vaš sadržaj.',
  'View Online' => 'Vidi Online',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} sviđa se vaš {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} sviđa se {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} sviđa se vaš {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} sviđa se {contentTitle}.',
);
