<?php
return array (
  ' likes this.' => ' se to líbí.',
  '<strong>Users</strong> who like this' => '<strong>Uživatelé</strong>, kterým se to líbí',
  'Like' => 'Líbí se mi',
  'Unlike' => 'Už se mi nelíbí',
  'You' => 'Vy',
  'You like this.' => 'Vám se to líbí.',
  'and {count} more like this.' => 'a dalším {count} lidem se to líbí.',
);
