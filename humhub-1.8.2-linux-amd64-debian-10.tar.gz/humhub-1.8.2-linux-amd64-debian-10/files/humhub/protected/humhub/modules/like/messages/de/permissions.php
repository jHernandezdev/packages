<?php
return array (
  'Allows user to like content' => 'Erlaubt dem Benutzer Inhalte zu "liken"',
  'Can like' => 'Inhalte liken',
);
