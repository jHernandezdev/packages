<?php
return array (
  'Likes' => 'M\'agrades',
  'Receive Notifications when someone likes your content.' => 'Rebre notificacions quan a algú li agradi el teu contingut.',
  'View Online' => 'Vore en línia',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} li agrada el teu {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} li agrada {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} li agrada el teu {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} li agrada {contentTitle}.',
);
