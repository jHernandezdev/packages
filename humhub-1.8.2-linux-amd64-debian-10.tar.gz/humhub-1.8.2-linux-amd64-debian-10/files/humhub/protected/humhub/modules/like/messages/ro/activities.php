<?php
return array (
  'Likes' => 'Aprecieri',
  'Whenever someone likes something (e.g. a post or comment).' => 'Oricând cineva apreciază ceva (ex: o postare sau comentariu).',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} apreciază {contentTitle}',
);
