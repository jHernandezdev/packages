<?php
return array (
  ' likes this.' => ' curtiu isso.',
  '<strong>Users</strong> who like this' => '<strong>Usuários</strong> que curtiram isso',
  'Like' => 'Curtir',
  'Unlike' => 'Descurtir',
  'You' => 'Você',
  'You like this.' => 'Você curtiu isso.',
  'and {count} more like this.' => 'e mais {count} curtiram isso.',
);
