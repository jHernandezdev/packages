<?php
return array (
  'Likes' => '',
  'Receive Notifications when someone likes your content.' => '',
  'View Online' => 'በመስመር ላይ ሆነው ይመልከቱ',
  '{displayNames} likes your {contentTitle}.' => '',
  '{displayNames} likes {contentTitle}.' => '',
  '{displayName} likes your {contentTitle}.' => '',
  '{displayName} likes {contentTitle}.' => '',
);
