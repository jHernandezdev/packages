<?php
return array (
  'Likes' => 'Kedvelések',
  'Receive Notifications when someone likes your content.' => 'Értesítések fogadása, ha valaki kedveli valamilyen tartalmad.',
  'View Online' => 'Megtekintés online',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} kedveli ezt: {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} kedveli ezt: {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} kedveli ezt: {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} kedveli ezt: {contentTitle}.',
);
