<?php
return array (
  ' likes this.' => 'kedveli.',
  '<strong>Users</strong> who like this' => '<strong>Felhasználók</strong>, akiknek ez tetszik',
  'Like' => 'Tetszik',
  'Unlike' => 'Mégse tetszik',
  'You' => 'Te',
  'You like this.' => 'Te kedveled.',
  'and {count} more like this.' => 'és még {count} ember kedveli.',
);
