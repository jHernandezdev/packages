<?php
return array (
  'Likes' => 'Likes',
  'Whenever someone likes something (e.g. a post or comment).' => 'når noen liker noe (for eksempel et innlegg eller en kommentar)',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} liker {contentTitle}',
);
