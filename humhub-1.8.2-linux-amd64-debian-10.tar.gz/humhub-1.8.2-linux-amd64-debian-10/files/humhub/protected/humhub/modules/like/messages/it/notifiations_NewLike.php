<?php
return array (
  'New Like' => 'Nuovo "mi piace"',
);
