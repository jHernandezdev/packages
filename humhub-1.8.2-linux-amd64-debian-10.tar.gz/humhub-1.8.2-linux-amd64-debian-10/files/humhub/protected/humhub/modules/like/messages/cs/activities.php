<?php
return array (
  'Likes' => 'To se mi líbí',
  'Whenever someone likes something (e.g. a post or comment).' => 'Kdykoli někdo má něco rád  (například příspěvek nebo komentář).',
  '{userDisplayName} likes {contentTitle}' => 'Uživateli {userDisplayName} se líbí {contentTitle}',
);
