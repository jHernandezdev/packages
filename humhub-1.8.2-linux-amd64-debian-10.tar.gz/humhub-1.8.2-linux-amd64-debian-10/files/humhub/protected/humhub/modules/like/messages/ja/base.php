<?php
return array (
  ' likes this.' => 'これ「いいね！」',
  '<strong>Users</strong> who like this' => '「いいね！」した<strong>ユーザー</strong>',
  'Like' => 'いいね！',
  'Unlike' => 'いいね！取消し',
  'You' => 'あなた自身',
  'You like this.' => 'あなたは「いいね！」しています。',
  'and {count} more like this.' => '他{count}人が「いいね！」しています。',
);
