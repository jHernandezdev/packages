<?php
return array (
  'Likes' => 'Tykkäykset',
  'Whenever someone likes something (e.g. a post or comment).' => 'Aina kun joku haluaa jotain (esim. Viesti tai kommentti).',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} tykkää {contentTitle}',
);
