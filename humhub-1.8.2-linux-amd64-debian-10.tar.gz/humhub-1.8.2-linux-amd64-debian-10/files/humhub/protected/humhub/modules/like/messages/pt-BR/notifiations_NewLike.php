<?php
return array (
  'New Like' => 'Nova Curtida',
);
