<?php
return array (
  'New Like' => 'Új kedvelés',
);
