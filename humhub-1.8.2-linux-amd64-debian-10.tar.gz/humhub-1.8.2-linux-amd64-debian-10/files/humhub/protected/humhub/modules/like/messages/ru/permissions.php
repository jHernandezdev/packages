<?php
return array (
  'Allows user to like content' => 'Позволяет пользователю ставить отметку "Нравится"',
  'Can like' => 'Может лайкать',
);
