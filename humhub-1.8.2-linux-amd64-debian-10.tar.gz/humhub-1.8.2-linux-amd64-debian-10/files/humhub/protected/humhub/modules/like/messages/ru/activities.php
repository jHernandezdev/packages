<?php
/**
 * Translation: Paul (https://paul.bid) paulbid@protonmail.com
 * 
 */
return array (
  'Likes' => 'Лайки',
  'Whenever someone likes something (e.g. a post or comment).' => 'Всякий раз, когда кому-то что-то нравится (например: запись или комментарий).',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} нравится {contentTitle}',
);
