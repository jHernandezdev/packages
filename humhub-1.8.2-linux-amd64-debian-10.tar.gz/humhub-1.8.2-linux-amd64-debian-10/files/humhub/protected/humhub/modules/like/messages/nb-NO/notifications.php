<?php
return array (
  'Likes' => 'Liker',
  'Receive Notifications when someone likes your content.' => 'Få varsling når noen liker innhold du har publisert.',
  'View Online' => 'Se online',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} liker innlegget {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} liker {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} liker innlegget {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} liker {contentTitle}.',
);
