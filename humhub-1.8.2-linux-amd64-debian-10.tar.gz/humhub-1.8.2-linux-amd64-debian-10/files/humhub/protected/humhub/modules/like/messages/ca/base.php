<?php
return array (
  ' likes this.' => 'li agrada.',
  '<strong>Users</strong> who like this' => '<strong>Membres</strong> que els hi agrada això',
  'Like' => 'M\'agrada',
  'Unlike' => 'Ja no m\'agrada',
  'You' => 'Tu',
  'You like this.' => 'T\'agrada això.',
  'and {count} more like this.' => 'i {count} més els hi agrada això.',
);
