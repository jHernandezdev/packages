<?php
return array (
  'Likes' => '"Me fa goyos"',
  'Whenever someone likes something (e.g. a post or comment).' => 'Quan a belún le fa goyo bella cosa (ex. una publicación u un comentario)',
  '{userDisplayName} likes {contentTitle}' => 'A {userDisplayName} le fa goyo {contentTitle}',
);
