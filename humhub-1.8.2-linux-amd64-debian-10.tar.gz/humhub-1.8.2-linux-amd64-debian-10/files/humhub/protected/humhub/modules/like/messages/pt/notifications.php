<?php
return array (
  'Likes' => 'Laiques',
  'Receive Notifications when someone likes your content.' => 'Receber notificações quando alguém laica o teu conteúdo.',
  'View Online' => 'Ver online',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} laicou o teu {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} laicou {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} laicou o teu {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} laicou {contentTitle}.',
);
