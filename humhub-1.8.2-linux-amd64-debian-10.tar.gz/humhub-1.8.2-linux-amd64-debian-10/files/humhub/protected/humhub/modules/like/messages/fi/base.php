<?php
return array (
  ' likes this.' => ' tykkää tästä.',
  '<strong>Users</strong> who like this' => '<strong>Käyttäjät</strong> jotka tykkäävät tästä',
  'Like' => 'Tykkää',
  'Unlike' => 'En tykkää',
  'You' => 'Sinä',
  'You like this.' => 'Sinä tykkäät tästä',
  'and {count} more like this.' => 'ja {count} tykkää tästä.',
);
