<?php
return array (
  ' likes this.' => '',
  '<strong>Users</strong> who like this' => '',
  'Like' => '',
  'Unlike' => '',
  'You' => '',
  'You like this.' => '',
  'and {count} more like this.' => '',
);
