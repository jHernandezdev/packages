<?php
return array (
  'Likes' => 'Tykkäykset',
  'Receive Notifications when someone likes your content.' => 'Saa ilmoituksia kun joku tykkä sisällöstäsi',
  'View Online' => 'Näytä verkossa',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} tykkäävät kohteesta {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} tykkäävät {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} tykkää kohteesta {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} tykkää {contentTitle}.',
);
