<?php
/**
 * Translation: Paul (https://paul.bid) paulbid@protonmail.com
 * 
 */
return array (
  'Likes' => 'Лайки',
  'Receive Notifications when someone likes your content.' => 'Получать уведомления, когда кому-то нравится Ваш контент.',
  'View Online' => 'Посмотреть на сайте',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} нравится Ваша запись {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} нравится {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} понравилась Ваша запись {contentTitle}',
  '{displayName} likes {contentTitle}.' => '{displayName} понравилось {contentTitle}.',
);
