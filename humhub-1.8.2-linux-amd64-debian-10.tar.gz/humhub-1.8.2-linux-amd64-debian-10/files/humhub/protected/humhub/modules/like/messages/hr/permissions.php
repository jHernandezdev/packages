<?php
return array (
  'Allows user to like content' => 'Omogućite korisniku da lajka sadržaj',
  'Can like' => 'Može lajkovati',
);
