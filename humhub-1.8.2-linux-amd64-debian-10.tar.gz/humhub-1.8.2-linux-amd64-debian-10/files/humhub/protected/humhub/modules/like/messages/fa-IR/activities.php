<?php
return array (
  'Likes' => 'پسندها',
  'Whenever someone likes something (e.g. a post or comment).' => 'هرگاه کسی چیزی را می‌پسندد (مثلا پست یا دیدگاه).',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} {contentTitle} را می‌پسندد',
);
