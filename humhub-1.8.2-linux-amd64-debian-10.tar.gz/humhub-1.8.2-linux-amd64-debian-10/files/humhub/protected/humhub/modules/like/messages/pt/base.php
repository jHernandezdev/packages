<?php
return array (
  ' likes this.' => ' laica isto.',
  '<strong>Users</strong> who like this' => '<strong>Pessoas</strong> que laicaram isto',
  'Like' => 'Laicar',
  'Unlike' => 'Deslaicar',
  'You' => 'Tu',
  'You like this.' => 'Tu laicas isto.',
  'and {count} more like this.' => ' e {count} mais laicaram isto.',
);
