<?php
return array (
  'New Like' => 'Novo Laique',
);
