<?php
return array (
  ' likes this.' => '赞这个。',
  '<strong>Users</strong> who like this' => '点赞用户',
  'Like' => '赞',
  'Unlike' => '取消赞',
  'You' => '你',
  'You like this.' => '你赞了这个。',
  'and {count} more like this.' => '和其它{count}人点赞了这个.',
);
