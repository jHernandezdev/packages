<?php
return array (
  'Likes' => 'Patīk',
  'Whenever someone likes something (e.g. a post or comment).' => 'Ikreiz, kad kāds patīk kaut kas (piem. ziņa, vai komentārs).',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} patīk {contentTitle}',
);
