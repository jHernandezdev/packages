<?php
return array (
  'Likes' => '',
  'Receive Notifications when someone likes your content.' => '',
  'View Online' => 'Shiko Online',
  '{displayNames} likes your {contentTitle}.' => '',
  '{displayNames} likes {contentTitle}.' => '',
  '{displayName} likes your {contentTitle}.' => '',
  '{displayName} likes {contentTitle}.' => '',
);
