<?php
return array (
  'New Like' => 'Yeni Beğeni',
);
