<?php
return array (
  'New Like' => 'Nuevo Me gusta',
);
