<?php
return array (
  'Allows user to like content' => 'Permite al usuario darle me gusta al contenido',
  'Can like' => 'Puede gustar',
);
