<?php
return array (
  'Likes' => 'Sviđa',
  'Whenever someone likes something (e.g. a post or comment).' => 'Kad god se nekome sviđa nešto (npr. post ili komentar).',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} sviđa se {contentTitle}',
);
