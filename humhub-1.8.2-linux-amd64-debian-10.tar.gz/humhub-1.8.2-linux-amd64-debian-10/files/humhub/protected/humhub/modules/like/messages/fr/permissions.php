<?php
return array (
  'Allows user to like content' => 'Autoriser l\'utilisateur à cliquer sur "J\'aime".',
  'Can like' => 'J\'aime',
);
