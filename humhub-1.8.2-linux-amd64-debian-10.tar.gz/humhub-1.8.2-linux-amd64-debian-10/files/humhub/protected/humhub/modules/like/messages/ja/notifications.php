<?php
return array (
  'Likes' => 'いいね！',
  'Receive Notifications when someone likes your content.' => 'あなたの投稿やコメントに「いいね！」がついたときに通知を受け取る',
  'View Online' => 'オンラインで見る',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} があなたの {contentTitle} に「いいね！」しました。',
  '{displayNames} likes {contentTitle}.' => '{displayNames} が {contentTitle} に「いいね！」しました。',
  '{displayName} likes your {contentTitle}.' => '{displayName} さんがあなたの {contentTitle} に「いいね！」しました。',
  '{displayName} likes {contentTitle}.' => '{displayName} さんが {contentTitle} に「いいね！」しました。',
);
