<?php
return array (
  'Likes' => 'Patīk',
  'Receive Notifications when someone likes your content.' => 'Saņemt notifikācijas kad kādam patīk tavs saturs.',
  'View Online' => 'Skatīties tiešsaistē',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} patīk tavs {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} patīk {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} patīk tavs {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} patīk {contentTitle}.',
);
