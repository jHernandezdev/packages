<?php
return array (
  'Likes' => 'Curtidas',
  'Whenever someone likes something (e.g. a post or comment).' => 'Sempre que alguém curtir alguma coisa (exemplo: uma publicação ou um comentário)',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} curtiu {contentTitle}',
);
