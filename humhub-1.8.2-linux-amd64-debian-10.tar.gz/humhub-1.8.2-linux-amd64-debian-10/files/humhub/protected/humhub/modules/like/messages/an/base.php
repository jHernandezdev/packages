<?php
return array (
  ' likes this.' => 'le fa goyo.',
  '<strong>Users</strong> who like this' => '<strong>Usuarios</strong> que les fa goyo',
  'Like' => 'Me fa goyo',
  'Unlike' => 'Ya no me fa goyo',
  'You' => 'Tu',
  'You like this.' => 'T\'ha feito goyo',
  'and {count} more like this.' => 'and {count} mas como iste.',
);
