<?php
return array (
  'New Like' => 'Neues "Gefällt mir"',
);
