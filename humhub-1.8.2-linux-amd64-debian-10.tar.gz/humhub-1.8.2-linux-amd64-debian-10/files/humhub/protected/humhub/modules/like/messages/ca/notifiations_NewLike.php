<?php
return array (
  'New Like' => 'Nou m\'agrada',
);
