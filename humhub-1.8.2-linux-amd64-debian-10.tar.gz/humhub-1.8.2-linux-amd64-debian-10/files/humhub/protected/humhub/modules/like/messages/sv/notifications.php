<?php
return array (
  'Likes' => 'Likes',
  'Receive Notifications when someone likes your content.' => 'Få notis när någon gillar ditt innehåll.',
  'View Online' => 'Visa online',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} gillar {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} gillar {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayNames} gillar {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayNames} gillar {contentTitle}.',
);
