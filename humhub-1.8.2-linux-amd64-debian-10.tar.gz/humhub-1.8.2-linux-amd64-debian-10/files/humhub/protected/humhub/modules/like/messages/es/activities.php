<?php
return array (
  'Likes' => 'Me gusta',
  'Whenever someone likes something (e.g. a post or comment).' => 'Siempre que a alguien le guste algo (ej: una publicación o un comentario).',
  '{userDisplayName} likes {contentTitle}' => 'A {userDisplayName} le gusta {contentTitle}',
);
