<?php
return array (
  'New Like' => 'Nuevo "me fa goyo"',
);
