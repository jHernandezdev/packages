<?php
return array (
  'New Like' => 'Novi \'\'Like\'\'',
);
