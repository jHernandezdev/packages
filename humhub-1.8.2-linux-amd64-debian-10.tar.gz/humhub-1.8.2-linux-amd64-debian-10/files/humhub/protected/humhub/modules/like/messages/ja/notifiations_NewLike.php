<?php
return array (
  'New Like' => 'New Like',
);
