<?php
return array (
  ' likes this.' => 'beğendi.',
  '<strong>Users</strong> who like this' => '<strong>Hangi</strong> kullanıcılar beğendi',
  'Like' => 'Beğen',
  'Unlike' => 'Beğenme',
  'You' => 'Sen',
  'You like this.' => 'Beğendin.',
  'and {count} more like this.' => 've {count} kişi beğendi.',
);
