<?php
return array (
  'Likes' => 'Piace',
  'Receive Notifications when someone likes your content.' => 'Ricevi una notifica quando a qualcuno piace il tuo contenuto.',
  'View Online' => 'Vedi online',
  '{displayNames} likes your {contentTitle}.' => 'A {displayNames} piacciono il tuo {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => 'A {displayNames} piacciono {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => 'A {displayName} piace il tuo {contentTitle}.',
  '{displayName} likes {contentTitle}.' => 'A {displayName} piace {contentTitle}.',
);
