<?php
return array (
  'Likes' => 'אהבות',
  'Receive Notifications when someone likes your content.' => '',
  'View Online' => 'צפיה ישירה',
  '{displayNames} likes your {contentTitle}.' => '',
  '{displayNames} likes {contentTitle}.' => '',
  '{displayName} likes your {contentTitle}.' => '',
  '{displayName} likes {contentTitle}.' => '',
);
