<?php
return array (
  'New Like' => 'Nya likes',
);
