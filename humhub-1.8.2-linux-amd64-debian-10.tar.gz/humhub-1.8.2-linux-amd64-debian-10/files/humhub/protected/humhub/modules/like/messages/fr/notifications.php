<?php
return array (
  'Likes' => 'J\'aime(s)',
  'Receive Notifications when someone likes your content.' => 'Recevoir une notification lorsqu\'on aime mes publications.',
  'View Online' => 'Voir en ligne',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} aiment votre {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} aiment {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} aime votre {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} aime {contentTitle}.',
);
