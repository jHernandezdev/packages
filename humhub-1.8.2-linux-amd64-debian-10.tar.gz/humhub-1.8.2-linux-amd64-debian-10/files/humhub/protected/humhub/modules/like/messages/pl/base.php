<?php
return array (
  ' likes this.' => ' lubi to. ',
  '<strong>Users</strong> who like this' => '<strong>Użytkownicy</strong> którzy lubią to ',
  'Like' => 'Lubię  to',
  'Unlike' => 'Nie lubię ',
  'You' => 'Ty',
  'You like this.' => 'Ty to lubisz.',
  'and {count} more like this.' => 'i {count} więcej lubi to. ',
);
