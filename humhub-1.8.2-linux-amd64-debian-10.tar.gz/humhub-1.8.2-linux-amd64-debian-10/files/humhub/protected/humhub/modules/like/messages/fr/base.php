<?php
return array (
  ' likes this.' => ' aime ça.',
  '<strong>Users</strong> who like this' => '<strong>Membres</strong> qui aiment ça',
  'Like' => 'J\'aime',
  'Unlike' => 'Je n\'aime plus',
  'You' => 'Vous',
  'You like this.' => 'Vous aimez.',
  'and {count} more like this.' => 'et {count,plural,=0{# autre aime} =1{# autre aime} other{# autres aiment}} ça.',
);
