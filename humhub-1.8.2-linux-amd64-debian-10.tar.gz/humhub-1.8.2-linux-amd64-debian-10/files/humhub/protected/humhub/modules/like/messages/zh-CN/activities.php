<?php
return array (
  'Likes' => '赞',
  'Whenever someone likes something (e.g. a post or comment).' => '每当有人赞了你的文章或者评论。',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} 赞了 {contentTitle}',
);
