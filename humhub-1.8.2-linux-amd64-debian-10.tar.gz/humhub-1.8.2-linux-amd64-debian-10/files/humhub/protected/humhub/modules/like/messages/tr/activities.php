<?php
return array (
  'Likes' => '',
  'Whenever someone likes something (e.g. a post or comment).' => '',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} beğendi {contentTitle}',
);
