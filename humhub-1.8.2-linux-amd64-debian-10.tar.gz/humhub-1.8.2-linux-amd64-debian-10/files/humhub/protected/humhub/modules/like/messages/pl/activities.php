<?php
return array (
  'Likes' => 'Polubień',
  'Whenever someone likes something (e.g. a post or comment).' => 'Gdy ktokolwiek polubi cokolwiek (np. wpis lub komentarz)',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} lubi {contentTitle} ',
);
