<?php
return array (
  'New Like' => 'Nouveau J\'aime',
);
