<?php
return array (
  'Likes' => 'Me gusta',
  'Receive Notifications when someone likes your content.' => 'Recibir notificaciones cuando a alguien le guste tu contenido.',
  'View Online' => 'Ver en línea',
  '{displayNames} likes your {contentTitle}.' => 'A {displayNames} le gusta tu {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => 'A {displayNames} le gusta {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => 'A {displayName} le gusta tu {contentTitle}.',
  '{displayName} likes {contentTitle}.' => 'A {displayName} le gusta {contentTitle}.',
);
