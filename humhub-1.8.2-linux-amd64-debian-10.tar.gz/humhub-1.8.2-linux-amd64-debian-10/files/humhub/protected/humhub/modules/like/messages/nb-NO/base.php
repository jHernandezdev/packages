<?php
return array (
  ' likes this.' => 'liker dette.',
  '<strong>Users</strong> who like this' => '<strong>Brukere</strong> som liker dette',
  'Like' => 'Lik',
  'Unlike' => 'Liker ikke',
  'You' => 'Du',
  'You like this.' => 'Du liker dette.',
  'and {count} more like this.' => 'og {count} flere liker dette.',
);
