<?php
return array (
  'Likes' => 'Curtidas',
  'Receive Notifications when someone likes your content.' => 'Receber notificações quando alguém curtir seu conteúdo.',
  'View Online' => 'Ver Online',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} curtiram {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} curtiram {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} curtiu {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} curtiu {contentTitle}.',
);
