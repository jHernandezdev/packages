<?php
return array (
  'Likes' => 'Likes',
  'Whenever someone likes something (e.g. a post or comment).' => 'Närsom någon gillar något (eg inlägg eller kommentar)',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} gillar {contentTitle}',
);
