<?php
return array (
  'Likes' => '',
  'Receive Notifications when someone likes your content.' => '',
  'View Online' => 'Δες σε σύνδεση',
  '{displayNames} likes your {contentTitle}.' => '',
  '{displayNames} likes {contentTitle}.' => '',
  '{displayName} likes your {contentTitle}.' => '',
  '{displayName} likes {contentTitle}.' => '',
);
