<?php
return array (
  ' likes this.' => 'apreciază asta.',
  '<strong>Users</strong> who like this' => '<strong>Membri</strong> ce au apreciat asts',
  'Like' => 'Apreciază',
  'Unlike' => 'Nu mai aprecia',
  'You' => 'Tu',
  'You like this.' => 'Apreciezi asta.',
  'and {count} more like this.' => 'și încă {count} alții apreciați asta.',
);
