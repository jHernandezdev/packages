<?php
return array (
  ' likes this.' => 'این را می‌پسندد.',
  '<strong>Users</strong> who like this' => '<strong>کاربرانی</strong> که این را پسندیده‌اند',
  'Like' => 'می‌پسندم',
  'Unlike' => 'نمی‌پسندم',
  'You' => 'شما',
  'You like this.' => 'این را می‌پسندید.',
  'and {count} more like this.' => 'و {count} نفر دیگر این را می‌پسندند.',
);
