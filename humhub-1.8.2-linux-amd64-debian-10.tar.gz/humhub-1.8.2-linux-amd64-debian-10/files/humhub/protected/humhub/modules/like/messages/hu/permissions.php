<?php
return array (
  'Allows user to like content' => 'Lehetővé teszi a felhasználók számára, hogy kedveljék a tartalmat',
  'Can like' => 'Kedvelhet',
);
