<?php
return array (
  'Likes' => 'Gefällt mir',
  'Receive Notifications when someone likes your content.' => 'Benachrichtigung empfangen, wenn jemandem deine Inhalte gefallen.',
  'View Online' => 'Online ansehen',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} gefällt dein {contentTitle}.
',
  '{displayNames} likes {contentTitle}.' => '{displayNames} gefällt {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} gefällt dein {contentTitle}.
',
  '{displayName} likes {contentTitle}.' => '{displayName} gefällt {contentTitle}.',
);
