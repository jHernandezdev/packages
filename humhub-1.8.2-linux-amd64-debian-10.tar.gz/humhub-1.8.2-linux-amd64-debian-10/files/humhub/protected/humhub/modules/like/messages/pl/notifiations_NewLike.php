<?php
return array (
  'New Like' => 'Nowe polubienie',
);
