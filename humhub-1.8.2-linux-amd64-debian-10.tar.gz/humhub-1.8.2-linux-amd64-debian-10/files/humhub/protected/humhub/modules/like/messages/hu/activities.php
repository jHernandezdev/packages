<?php
return array (
  'Likes' => 'Kedvelések',
  'Whenever someone likes something (e.g. a post or comment).' => 'Ha bárki bármikor kedvel valamit (pl.: bejegyzést vagy hozzászólást).',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} kedveli ezt: {contentTitle}',
);
