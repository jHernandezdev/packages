<?php
return array (
  'Allows user to like content' => 'Permetti agli utenti di mettere "mi piace"',
  'Can like' => 'Può mettere "mi piace"',
);
