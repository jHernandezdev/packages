<?php
return array (
  'Likes' => 'いいね！',
  'Whenever someone likes something (e.g. a post or comment).' => '誰かが投稿やコメントに「いいね！」するたびに。',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} さんが、{contentTitle} に「いいね！」しました。',
);
