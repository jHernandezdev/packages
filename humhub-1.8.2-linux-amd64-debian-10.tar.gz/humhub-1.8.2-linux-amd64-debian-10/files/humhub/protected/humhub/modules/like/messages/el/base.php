<?php
return array (
  ' likes this.' => '',
  '<strong>Users</strong> who like this' => '',
  'Like' => 'Μου αρέσει',
  'Unlike' => 'Δε μου αρέσει',
  'You' => '',
  'You like this.' => '',
  'and {count} more like this.' => '',
);
