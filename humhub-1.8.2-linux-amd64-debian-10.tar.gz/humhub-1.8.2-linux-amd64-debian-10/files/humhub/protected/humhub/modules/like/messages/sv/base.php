<?php
return array (
  ' likes this.' => 'Gillar detta.',
  '<strong>Users</strong> who like this' => '<strong>Användare</strong> som gillar detta',
  'Like' => 'Like',
  'Unlike' => 'Ogilla',
  'You' => 'Du',
  'You like this.' => 'Du gillar detta.',
  'and {count} more like this.' => 'och {count} fler gillar detta.',
);
