<?php
return array (
  ' likes this.' => 'šis patīk.',
  '<strong>Users</strong> who like this' => '<strong>Lietotāji</strong> kam šis patika',
  'Like' => 'Patīk',
  'Unlike' => 'Nepatīk',
  'You' => 'Tu',
  'You like this.' => 'Tev šis patīk.',
  'and {count} more like this.' => 'un vēl {count} šis patīk.',
);
