<?php
return array (
  'Likes' => 'J\'aime(s)',
  'Whenever someone likes something (e.g. a post or comment).' => 'Chaque fois que quelqu\'un aime quelque chose (p.ex. une publication ou un commentaire)',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} aime {contentTitle}',
);
