<?php
return array (
  'Likes' => 'M\'agrades',
  'Whenever someone likes something (e.g. a post or comment).' => 'Sempre que a algú li agrada alguna cosa (per exemple, una publicació o un comentari).',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} li agrada {contentTitle}',
);
