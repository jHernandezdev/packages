<?php
return array (
  ' likes this.' => 'le gusta.',
  '<strong>Users</strong> who like this' => '<strong>Usuarios</strong> a los que les gusta esto',
  'Like' => 'Me gusta',
  'Unlike' => 'Ya no me gusta',
  'You' => 'Tú',
  'You like this.' => 'Te gusta esto.',
  'and {count} more like this.' => 'y a {count} más les gusta esto.',
);
