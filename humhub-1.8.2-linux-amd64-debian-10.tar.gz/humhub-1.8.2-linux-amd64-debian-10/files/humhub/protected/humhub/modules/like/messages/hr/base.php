<?php
return array (
  ' likes this.' => 'sviđa se ovo.',
  '<strong>Users</strong> who like this' => '<strong>Korisnici</strong> kojima se ovo sviđa',
  'Like' => 'Sviđa se',
  'Unlike' => 'Ne sviđa se',
  'You' => 'Vi',
  'You like this.' => 'Vama se sviđa ovo.',
  'and {count} more like this.' => 'i {count} više sviđa se ovo.',
);
