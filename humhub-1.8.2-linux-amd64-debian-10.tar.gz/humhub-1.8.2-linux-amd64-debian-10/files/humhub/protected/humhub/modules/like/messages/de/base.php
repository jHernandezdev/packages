<?php
return array (
  ' likes this.' => ' gefällt das.',
  '<strong>Users</strong> who like this' => '<strong>Benutzer</strong>, denen das gefällt',
  'Like' => 'Gefällt mir',
  'Unlike' => 'Gefällt mir nicht mehr',
  'You' => 'Dir',
  'You like this.' => 'Dir gefällt das.',
  'and {count} more like this.' => 'und {count} anderen gefällt das.',
);
