<?php
return array (
  'Likes' => 'Aprecieri',
  'Receive Notifications when someone likes your content.' => 'Primește Notificări atunci când cineva îți apreciază conținutul.',
  'View Online' => 'Vizualizați Online',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} ți-au apreciat {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} au apreciat {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} ți-a apreciat {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} a apreciat {contentTitle}.',
);
