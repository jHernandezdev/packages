<?php
return array (
  'Likes' => 'Polubienia',
  'Receive Notifications when someone likes your content.' => 'Otrzymuj powiadomienia gdy ktoś polubi coś co dodałeś.',
  'View Online' => 'Pokaż online',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} lubią Twój {contentTitle}.',
  '{displayNames} likes {contentTitle}.' => '{displayNames} lubią {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => '{displayName} lubi Twój {contentTitle}.',
  '{displayName} likes {contentTitle}.' => '{displayName} lubi {contentTitle}.',
);
