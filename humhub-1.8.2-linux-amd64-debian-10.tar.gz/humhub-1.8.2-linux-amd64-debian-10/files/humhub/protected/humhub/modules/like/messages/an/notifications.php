<?php
return array (
  'Likes' => 'Me fa goyos',
  'Receive Notifications when someone likes your content.' => 'Recibir notificacions quan a belún le fa goyo o tuyo conteniu.',
  'View Online' => 'Veyer en linia',
  '{displayNames} likes your {contentTitle}.' => 'A {displayNames} l\'han feito goyo o tuyo {contentTitle}',
  '{displayNames} likes {contentTitle}.' => 'A {displayNames} l\'han feito goyo {contentTitle}.',
  '{displayName} likes your {contentTitle}.' => 'A {displayName} l\'ha feito goyo o tuyo {contentTitle}.',
  '{displayName} likes {contentTitle}.' => 'A {displayName} l\'ha feito goyo {contentTitle}.',
);
