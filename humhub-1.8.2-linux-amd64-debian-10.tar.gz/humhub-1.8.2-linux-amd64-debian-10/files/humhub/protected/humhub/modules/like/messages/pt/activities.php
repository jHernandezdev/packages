<?php
return array (
  'Likes' => 'Laiques',
  'Whenever someone likes something (e.g. a post or comment).' => 'Sempre que alguém laica algo (p.ex. uma posta ou comentário).',
  '{userDisplayName} likes {contentTitle}' => '{userDisplayName} laica {contentTitle}',
);
