<?php
return array (
  'New Like' => 'Nytt likerklikk',
);
