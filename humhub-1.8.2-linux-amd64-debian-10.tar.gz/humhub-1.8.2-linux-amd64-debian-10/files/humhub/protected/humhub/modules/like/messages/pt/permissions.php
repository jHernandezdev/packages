<?php
return array (
  'Allows user to like content' => 'Permitir à pessoa laicar conteúdo',
  'Can like' => 'Pode laicar',
);
