<?php
return array (
  'Likes' => '赞',
  'Receive Notifications when someone likes your content.' => '当有人赞了你的内容时接收提醒。',
  'View Online' => '在线看',
  '{displayNames} likes your {contentTitle}.' => '{displayNames} 赞了你的 {contentTitle}。',
  '{displayNames} likes {contentTitle}.' => '{displayNames} 赞了 {contentTitle}。',
  '{displayName} likes your {contentTitle}.' => '{displayName} 赞了你的 {contentTitle}。',
  '{displayName} likes {contentTitle}.' => '{displayName} 赞了 {contentTitle}。',
);
