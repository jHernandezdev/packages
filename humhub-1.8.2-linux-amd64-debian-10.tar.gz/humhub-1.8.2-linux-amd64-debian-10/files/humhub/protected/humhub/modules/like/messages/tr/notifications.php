<?php
return array (
  'Likes' => '',
  'Receive Notifications when someone likes your content.' => '',
  'View Online' => 'Çevrimiçi Görüntüleme',
  '{displayNames} likes your {contentTitle}.' => '',
  '{displayNames} likes {contentTitle}.' => '{displayNames}, {contentTitle} beğendi.',
  '{displayName} likes your {contentTitle}.' => '',
  '{displayName} likes {contentTitle}.' => '{displayName}, {contentTitle} beğendi.',
);
